import pandas as pd
df =pd.read_excel("ASM2_PBI_Exel.xlsx", sheet_name="Sheet1")
pd.set_option('display.max_rows', 101)

filtered_df = df[df["Brand"].isin(["Gucci","Louis Vuitton"])]

print(filtered_df)
