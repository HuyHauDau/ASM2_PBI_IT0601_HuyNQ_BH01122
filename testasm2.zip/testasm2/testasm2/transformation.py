import pandas as pd 
df = pd.read_excel("ASM2_PBI_Exel.xlsx", sheet_name="Sheet1")
pd.set_option('display.max_row', 101)
df["Trending Score"] = pd.to_numeric(df["Trending Score"], errors="coerce").fillna(0)
print(df)
