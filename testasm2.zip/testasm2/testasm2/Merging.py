import pandas as pd
df1 = pd.read_excel("ASM2_PBI_Exel.xlsx",sheet_name="Sheet1")
df2 = pd.read_excel("ASM2_BI_Exel_2.xlsx",sheet_name="Sheet1")

pd.set_option('display.max_rows', 101)
df = pd.merge(df1, df2, on=['Product ID','Product Name'])
print(df)